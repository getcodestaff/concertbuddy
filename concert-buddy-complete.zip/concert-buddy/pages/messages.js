export default function Messages() {
  return (
    <div className="p-8 text-center">
      <h2 className="text-2xl font-bold">Messages</h2>
      <p className="mt-2">(Chat feature coming soon...)</p>
    </div>
  );
}
