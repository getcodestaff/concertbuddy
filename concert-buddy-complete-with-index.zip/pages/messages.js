export default function Messages() {
  return <div className="p-8 text-xl text-center text-gray-800">Messages Inbox Page</div>;
}
