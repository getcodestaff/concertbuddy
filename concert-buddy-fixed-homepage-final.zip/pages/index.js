export default function Home() {
  return <div className="p-8 text-xl text-center text-gray-800">Concert Buddy Homepage with posts, filters, login, and messaging.</div>;
}
