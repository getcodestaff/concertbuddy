export default function Profile() {
  return <div className="p-8 text-xl text-center text-gray-800">Profile Editor Page</div>;
}
